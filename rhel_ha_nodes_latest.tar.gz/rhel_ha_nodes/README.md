# RHEL 8.x "HA" Vanilla - Ansible automation (nodes only)

"HA" here is provided by the VMware Gold cluster (placement, vSphere HA, DRS VM-Host rules). There is **no
operating-system cluster**: no Pacemaker, fencing, quorum, VIP or shared disk. The build is two standard RHEL VMs,
each with the standard post-install agents and onboarding. Standalone roles (`aap.shared.*`) are reused unchanged.

This is the simplified branch. The OS-cluster version (plays 1d and 4, roles 32-37, 18512_ha_vip_reserve, shared disk,
`site_resume.yml`) is kept on the previous branch.

## Flow (`site.yml`)

| Play | What | Roles |
|---|---|---|
| 0 | Validate inputs, request mail, register `ha-node1-build` / `ha-node2-build`, init state | 31 (controller), 98, `18512_ha_inventory` |
| 1a | Name the nodes (serial) | 03 (node 1), `18512_ha_name_derive` (node 2) |
| 1b | Cluster-level allocation, once | 04, 05, 08, 09 |
| 1c | Per node (serial) | `18512_ha_datastore_select` (copy of 06, chamber prefix), 06 host check, 07 IP/DNS, 07 second IP |
| 2a | Provision (parallel, powered off) | 10, 11, 12 |
| 2b | Add each VM to its chamber VM group before first power-on | 38 |
| 3a | Configure each node (parallel) | 13, 28, 14, 29, 30, 16, 15 (optional), 18, 20, 21 install + onboard, 22, 23, 24 |
| 3b | Cohesity (serial; skip with `ha_run_backup=false`) | 26 |
| 3c | OpsRamp onboarding | 27 |
| 4 | Close: CloudStudio, mails, resume block, fail the job if a stage failed | `18512_ha_cloudstudio_update`, `18512_ha_email_success`, 99, 96, `18512_ha_state_export` |

Gates (tag `always`) run after each parallel play and turn a node failure into the global `failmsg`.

## Placement (two chambers)

Node 1 is placed in DC1 (`dc1-chz1`, CHZ1) and node 2 in DC2 (`dc2-chz2`, CHZ2); override per node with
`rhel_ha_nodes[].dc`. Both must differ. The node's chamber is `placement_dc`; `dcname` stays the cluster's DC1 and keeps
selecting the vCenter, datacenter and network for every role (as in the Windows flow).

| Follows `placement_dc` (node) | Stays on `dcname` (cluster, DC1) |
|---|---|
| datastore prefix CHZ1-/CHZ2- (`18512_ha_datastore_select`), Valuemation location (18), Cohesity DC (26), VM group (38) | vCenter, datacenter, cluster, VLAN and BlueCat range (04, 05, 06 host, 07, 10, 11) |

Role 38 only adds the VMs to the existing DRS VM groups; the existing "Run VMs on Hosts" rules do the pinning. Pass the
exact group names as `ha_vm_groups: {dc1-chz1: ..., dc2-chz2: ...}`; the job fails with a clear message if a group does not
exist. Optional extra: `ha_anti_affinity_rule: true` adds a VM-VM rule so the nodes also use different ESXi hosts.
`18512_ha_datastore_select` is a copy of role 06 with one line changed (the shared role is add-only); keep it in sync.

## Resume

Every standalone role skips itself when its output is already set (`x is none` guards). A failed job prints
**"Resume extra vars"** in the close play: only values that are set and true, with the addressing set (`ip`,
`subnetmask`, `gateway`, `dns1`, `dns2`) all or none. To resume:

1. In the job's extra vars delete `rhel_ha_nodes` (and `clustername` / `dcname` if present); keep `ha_vm_groups`.
2. Paste the block, keep every other request input, relaunch the same template.

Tags alone do not resume: the gates need the markers of the earlier plays. A role that fails halfway reruns in full;
role 28 (root reset) power-cycles the VM, so check the VM first.

## Inputs

`vars/ha_example.yml`: `rhel_ha_nodes` (exactly two; names both given or both derived) plus the standalone inputs
(`metalcategory`, `ostype`, `addontype`, `osversion`, `environmenttype`, `additionaldrives` ...). `gold+` is refused
(role 06 would fall back to bronze datastores). Secrets come from AAP credentials (`VMWARE_*_1/_2` etc.).

## Tests

`tests/run_tests.sh` (chamber and VM-group checks included, no network): stage runner, gate, inventory, name derivation, state export, mail
rendering, controller preflight (accepts and rejects) and the `site.yml` syntax check. Nothing here touches vCenter,
BlueCat or a VM; only an AAP run proves that.

## Not covered / open

- VM group names and "must" vs "should" on the Run VMs on Hosts rules: ask the VMware team.
- Node 2 uses the DC1 VLAN/BlueCat range (stretched cluster); confirm the VLAN is available on the chz2 hosts.
- Cohesity DC2 may not see a VM created through the DC1 vCenter: ask the backup team.
- Tenable / Nexpose: no role exists.
- Datastore health and storage-alert checks (SOP guideline): role 06 only looks at free space.
- Valuemation (role 18) failed on the provider; skip it with the flag you already use until it is fixed.
- Confirm in writing with the tracker owner that the OS cluster is out of scope.
