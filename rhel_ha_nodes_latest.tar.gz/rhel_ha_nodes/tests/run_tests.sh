#!/usr/bin/env bash
# Local tests, no network, no VMware, no target hosts.   Usage: tests/run_tests.sh
set -u
cd "$(dirname "$0")/.."
export ANSIBLE_CONFIG="$PWD/ansible.cfg" ANSIBLE_ROLES_PATH="$PWD/roles:$PWD/tests/roles"
pass=0; fail=0
ok()  { echo "PASS  $1"; pass=$((pass+1)); }
bad() { echo "FAIL  $1"; fail=$((fail+1)); }
run() { ansible-playbook -i localhost, "$@" >/tmp/ha_test.out 2>&1; }

run tests/test_ha_stage.yml && ok "stage runner (success, resume, failure, skip-after-failure)" || bad "stage runner"
run tests/test_gate.yml     && ok "gate (node failure, missing marker)" || bad "gate"
run tests/test_inventory.yml && ok "inventory: index hosts, derived names, resolve, duplicates" || bad "inventory"
run tests/test_name_derive.yml && ok "partner name derivation" || bad "partner name derivation"
run tests/test_state_export.yml && ok "state export (true only, pinned groups, round trip)" || bad "state export"
run tests/test_38_validate.yml && ok "role 38: chambers, group names, VM-vs-host group check" || bad "role 38 validation"
run tests/test_97_render.yml && ok "patched 97 renders the server block" || bad "patched 97 render"
run tests/test_31_controller.yml -e @vars/ha_example.yml && ok "preflight accepts example vars" || bad "preflight accepts example vars"
run tests/test_31_controller.yml -e @vars/ha_example.yml -e '{"rhel_ha_nodes":[{},{}]}' && ok "preflight accepts derived names" || bad "derived names"
run tests/test_31_controller.yml -e @vars/ha_example.yml -e '{"rhel_ha_nodes":[{"name":"a","dc":"DC2-CHZ2"},{"name":"c","dc":"dc1-chz1"}]}' && ok "preflight accepts swapped chambers" || bad "swapped chambers"
run tests/test_31_controller.yml -e @vars/ha_example.yml -e '{"metalcategory":"gold"}' && ok "preflight accepts gold" || bad "gold"

neg() { # name, json overrides
  if run tests/test_31_controller.yml -e @vars/ha_example.yml -e "$2"; then bad "preflight rejects: $1"; else ok "preflight rejects: $1"; fi
}
neg "one node"                 '{"rhel_ha_nodes":[{"name":"a"}]}'
neg "three nodes"              '{"rhel_ha_nodes":[{"name":"a"},{"name":"b"},{"name":"c"}]}'
neg "one named, one derived"   '{"rhel_ha_nodes":[{"name":"a"},{}]}'
neg "servername extra var"     '{"servername":"x"}'
neg "duplicate names"          '{"rhel_ha_nodes":[{"name":"a"},{"name":"a"}]}'
neg "bad node name"            '{"rhel_ha_nodes":[{"name":"a b"},{"name":"c"}]}'
neg "bad node ip"              '{"rhel_ha_nodes":[{"name":"a","ip":"10.0.0.999"},{"name":"c"}]}'
neg "both nodes in one chamber"  '{"rhel_ha_nodes":[{"name":"a","dc":"dc1-chz1"},{"name":"c","dc":"dc1-chz1"}]}'
neg "default + override clash"   '{"rhel_ha_nodes":[{"name":"a"},{"name":"c","dc":"dc1-chz1"}]}'
neg "unknown chamber"           '{"rhel_ha_nodes":[{"name":"a","dc":"dc9"},{"name":"c"}]}'
neg "no VM groups"              '{"ha_vm_groups":{}}'
neg "one VM group only"         '{"ha_vm_groups":{"dc1-chz1":"G"}}'
neg "gold+ (Elite)"            '{"metalcategory":"Gold+"}'

ansible-playbook -i localhost, site.yml --syntax-check -e @vars/ha_example.yml >/tmp/ha_test.out 2>&1 && ok "site.yml syntax" || bad "site.yml syntax"
echo "passed=$pass failed=$fail"; [ "$fail" -eq 0 ]
