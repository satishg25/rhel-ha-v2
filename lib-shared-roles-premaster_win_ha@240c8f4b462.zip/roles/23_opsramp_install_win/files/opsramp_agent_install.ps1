#requires -Version 5.1

[CmdletBinding()]
param(
    [Parameter()]
    [string]$SourceDirectory = 'C:\Temp\OpsRamp_MSI',

    [Parameter()]
    [string]$ServiceName = 'opsramp-agent',

    [Parameter()]
    [int]$ServiceStartTimeoutSeconds = 60,

    [Parameter()]
    [string]$LogFile = 'C:\Temp\OpsRampInstall.log'
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'

# Exit codes:
#   1 = Installation succeeded and service is Running
#  10 = Source directory does not exist
#  11 = Exactly one TXT command file was not found
#  13 = TXT command file is empty
#  14 = TXT does not begin with a valid msiexec command
#  15 = MSI filename was not found immediately after /i
#  16 = Invalid MSI filename was found after /i
#  17 = MSI named in the TXT file does not exist locally
#  18 = MSI path replacement failed
#  20 = MSI installation returned a failure exit code
#  21 = MSI initiated a restart, exit code 1641
#  30 = Expected OpsRamp service was not found
#  31 = OpsRamp service could not be started
#  32 = OpsRamp service did not reach Running status
#  99 = Unexpected PowerShell error

function Write-InstallLog {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [string]$Message,

        [Parameter()]
        [ValidateSet('INFO', 'WARNING', 'ERROR')]
        [string]$Level = 'INFO'
    )

    $timestamp = Get-Date -Format 'yyyy-MM-dd HH:mm:ss.fff'
    $logEntry = '{0} [{1}] {2}' -f $timestamp, $Level, $Message
    Write-Output $logEntry

    try {
        Add-Content -LiteralPath $LogFile -Value $logEntry -Encoding UTF8 -ErrorAction Stop
    }
    catch {
        Write-Output ('Unable to write to log file {0}: {1}' -f $LogFile, $_.Exception.Message)
    }
}

function Exit-OpsRampScript {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [int]$ExitCode,

        [Parameter(Mandatory)]
        [string]$Message,

        [Parameter()]
        [ValidateSet('INFO', 'WARNING', 'ERROR')]
        [string]$Level = 'ERROR'
    )

    Write-InstallLog -Message $Message -Level $Level
    Write-InstallLog -Message ('SCRIPT_EXIT_CODE={0}' -f $ExitCode) -Level $Level
    exit $ExitCode
}

try {
    $logDirectory = Split-Path -Path $LogFile -Parent

    if (
        -not [string]::IsNullOrWhiteSpace($logDirectory) -and
        -not (Test-Path -LiteralPath $logDirectory -PathType Container)
    ) {
        New-Item -Path $logDirectory -ItemType Directory -Force -ErrorAction Stop |
            Out-Null
    }

    if (Test-Path -LiteralPath $LogFile -PathType Leaf) {
        Remove-Item -LiteralPath $LogFile -Force -ErrorAction SilentlyContinue
    }

    Write-InstallLog -Message 'OPSRAMP_INSTALL_STARTED'
    Write-InstallLog -Message ('COMPUTER_NAME={0}' -f $env:COMPUTERNAME)
    Write-InstallLog -Message ('RUNNING_AS={0}\{1}' -f $env:USERDOMAIN, $env:USERNAME)
    Write-InstallLog -Message ('SOURCE_DIRECTORY={0}' -f $SourceDirectory)
    Write-InstallLog -Message ('SERVICE_NAME={0}' -f $ServiceName)

    if (-not (Test-Path -LiteralPath $SourceDirectory -PathType Container)) {
        Exit-OpsRampScript -ExitCode 10 -Message (
            'OpsRamp source directory does not exist: {0}' -f $SourceDirectory
        )
    }

    Write-InstallLog -Message 'Searching for the OpsRamp command TXT file.'

    $txtFiles = @(
        Get-ChildItem -LiteralPath $SourceDirectory -File -Filter '*.txt' -ErrorAction Stop
    )

    Write-InstallLog -Message ('TXT_FILE_COUNT={0}' -f $txtFiles.Count)

    if ($txtFiles.Count -ne 1) {
        $foundTxtFiles = if ($txtFiles.Count -gt 0) {
            ($txtFiles | Select-Object -ExpandProperty FullName) -join '; '
        }
        else {
            'None'
        }

        Exit-OpsRampScript -ExitCode 11 -Message (
            'Expected exactly one TXT file in {0}, but found {1}. Files: {2}' -f
            $SourceDirectory,
            $txtFiles.Count,
            $foundTxtFiles
        )
    }

    $txtFile = $txtFiles[0]
    Write-InstallLog -Message ('TXT_FILE={0}' -f $txtFile.FullName)
    Write-InstallLog -Message 'Reading installation command from the TXT file.'

    $installCommand = (
        Get-Content -LiteralPath $txtFile.FullName -Raw -ErrorAction Stop
    ).Trim()

    if ([string]::IsNullOrWhiteSpace($installCommand)) {
        Exit-OpsRampScript -ExitCode 13 -Message (
            'The installation command TXT file is empty: {0}' -f $txtFile.FullName
        )
    }

    $msiexecStartPattern = [regex]::new(
        '^\s*(?:"?[^"\r\n]*\\)?msiexec(?:\.exe)?"?(?=\s|$)',
        [System.Text.RegularExpressions.RegexOptions]::IgnoreCase
    )

    if (-not $msiexecStartPattern.IsMatch($installCommand)) {
        Exit-OpsRampScript -ExitCode 14 -Message (
            'The TXT file does not begin with a valid msiexec.exe command.'
        )
    }

    Write-InstallLog -Message 'Searching for the MSI filename immediately following /i.'

    # Matches only the MSI argument immediately following /i:
    #   /i "filename.msi"
    #   /i filename.msi
    $msiArgumentPattern = [regex]::new(
        '(?<InstallSwitch>(?i:/i)\s+)(?:"(?<QuotedMsi>[^"\r\n]+\.msi)"|(?<UnquotedMsi>[^\s"]+\.msi))'
    )

    $msiArgumentMatch = $msiArgumentPattern.Match($installCommand)

    if (-not $msiArgumentMatch.Success) {
        Exit-OpsRampScript -ExitCode 15 -Message (
            'No MSI filename was found immediately after the /i switch in the installation command.'
        )
    }

    if ($msiArgumentMatch.Groups['QuotedMsi'].Success) {
        $msiReferenceFromTxt = $msiArgumentMatch.Groups['QuotedMsi'].Value
    }
    else {
        $msiReferenceFromTxt = $msiArgumentMatch.Groups['UnquotedMsi'].Value
    }

    Write-InstallLog -Message ('MSI_REFERENCE_FROM_TXT={0}' -f $msiReferenceFromTxt)

    $msiFileNameFromTxt = [System.IO.Path]::GetFileName($msiReferenceFromTxt)

    if ([string]::IsNullOrWhiteSpace($msiFileNameFromTxt)) {
        Exit-OpsRampScript -ExitCode 16 -Message (
            'The value following /i does not contain a valid MSI filename.'
        )
    }

    if (-not $msiFileNameFromTxt.EndsWith(
        '.msi',
        [System.StringComparison]::OrdinalIgnoreCase
    )) {
        Exit-OpsRampScript -ExitCode 16 -Message (
            'The installation target following /i is not an MSI file: {0}' -f
            $msiFileNameFromTxt
        )
    }

    Write-InstallLog -Message ('MSI_FILENAME_FROM_TXT={0}' -f $msiFileNameFromTxt)

    $sourceDirectoryFullPath = [System.IO.Path]::GetFullPath($SourceDirectory).TrimEnd('\')
    $fullMsiPath = [System.IO.Path]::GetFullPath(
        (Join-Path -Path $sourceDirectoryFullPath -ChildPath $msiFileNameFromTxt)
    )

    # Prevent a path from the TXT content from escaping SourceDirectory.
    $expectedMsiParent = [System.IO.Path]::GetDirectoryName($fullMsiPath).TrimEnd('\')
    if (-not $expectedMsiParent.Equals(
        $sourceDirectoryFullPath,
        [System.StringComparison]::OrdinalIgnoreCase
    )) {
        Exit-OpsRampScript -ExitCode 16 -Message (
            'The MSI filename resolved outside the approved source directory.'
        )
    }

    Write-InstallLog -Message ('EXPECTED_LOCAL_MSI_PATH={0}' -f $fullMsiPath)

    if (-not (Test-Path -LiteralPath $fullMsiPath -PathType Leaf)) {
        $availableMsiFiles = @(
            Get-ChildItem -LiteralPath $SourceDirectory -File -Filter '*.msi' `
                -ErrorAction SilentlyContinue |
                Select-Object -ExpandProperty Name
        )

        $availableMsiText = if ($availableMsiFiles.Count -gt 0) {
            $availableMsiFiles -join '; '
        }
        else {
            'None'
        }

        Exit-OpsRampScript -ExitCode 17 -Message (
            'The MSI named in the TXT command was not found. Expected path: {0}. ' +
            'Available MSI files: {1}' -f
            $fullMsiPath,
            $availableMsiText
        )
    }

    $msiFileInfo = Get-Item -LiteralPath $fullMsiPath -ErrorAction Stop
    Write-InstallLog -Message ('MSI_FILE_SIZE_BYTES={0}' -f $msiFileInfo.Length)
    Write-InstallLog -Message 'Replacing the MSI filename with its full local path.'

    $installCommand = $msiArgumentPattern.Replace(
        $installCommand,
        [System.Text.RegularExpressions.MatchEvaluator] {
            param([System.Text.RegularExpressions.Match]$match)

            return '{0}"{1}"' -f $match.Groups['InstallSwitch'].Value, $fullMsiPath
        },
        1
    )

    $expectedInstallTarget = '"{0}"' -f $fullMsiPath

    if ($installCommand.IndexOf(
        $expectedInstallTarget,
        [System.StringComparison]::OrdinalIgnoreCase
    ) -lt 0) {
        Exit-OpsRampScript -ExitCode 18 -Message (
            'The MSI filename was detected, but replacement with the full local path was unsuccessful.'
        )
    }

    Write-InstallLog -Message ('MSI_PATH_REPLACEMENT_SUCCESS={0}' -f $fullMsiPath)

    # Do not log the complete command because WRAPPED_ARGUMENTS can contain secrets.
    Write-InstallLog -Message 'Executing the OpsRamp MSI installation command.'

    & "$env:SystemRoot\System32\cmd.exe" /d /s /c $installCommand
    $msiExitCode = $LASTEXITCODE

    Write-InstallLog -Message ('MSI_EXIT_CODE={0}' -f $msiExitCode)

    switch ($msiExitCode) {
        0 {
            Write-InstallLog -Message 'MSI installation completed successfully.'
        }

        1641 {
            Exit-OpsRampScript -ExitCode 21 -Level 'WARNING' -Message (
                'MSI exit code 1641 indicates that installation initiated a system restart. ' +
                'Service validation cannot be completed reliably until the restart is complete.'
            )
        }

        3010 {
            Write-InstallLog -Level 'WARNING' -Message (
                'MSI exit code 3010 indicates that installation succeeded and a restart is required. ' +
                'Service validation will still be attempted.'
            )
        }

        default {
            Exit-OpsRampScript -ExitCode 20 -Message (
                'OpsRamp MSI installation failed with MSI exit code {0}.' -f $msiExitCode
            )
        }
    }

    Write-InstallLog -Message ('Checking Windows service: {0}' -f $ServiceName)

    $service = Get-Service -Name $ServiceName -ErrorAction SilentlyContinue

    if ($null -eq $service) {
        $relatedServices = @(
            Get-Service -ErrorAction SilentlyContinue |
                Where-Object {
                    $_.Name -match '(?i)opsramp' -or
                    $_.DisplayName -match '(?i)opsramp'
                }
        )

        if ($relatedServices.Count -gt 0) {
            $relatedServiceDetails = (
                $relatedServices |
                    ForEach-Object {
                        '{0} [{1}] Status={2}' -f $_.Name, $_.DisplayName, $_.Status
                    }
            ) -join '; '

            Write-InstallLog -Level 'ERROR' -Message (
                'OPSRAMP_RELATED_SERVICES={0}' -f $relatedServiceDetails
            )
        }
        else {
            Write-InstallLog -Level 'ERROR' -Message 'OPSRAMP_RELATED_SERVICES=None'
        }

        Exit-OpsRampScript -ExitCode 30 -Message (
            'Expected OpsRamp service was not found: {0}' -f $ServiceName
        )
    }

    Write-InstallLog -Message ('SERVICE_DISPLAY_NAME={0}' -f $service.DisplayName)
    Write-InstallLog -Message ('SERVICE_INITIAL_STATUS={0}' -f $service.Status)

    if ($service.Status -ne 'Running') {
        Write-InstallLog -Message (
            'Service {0} is not running. Attempting to start it.' -f $ServiceName
        )

        try {
            Set-Service -Name $ServiceName -StartupType Automatic -ErrorAction Stop
            Start-Service -Name $ServiceName -ErrorAction Stop
        }
        catch {
            Exit-OpsRampScript -ExitCode 31 -Message (
                'Failed to start service {0}. Error: {1}' -f
                $ServiceName,
                $_.Exception.Message
            )
        }

        try {
            $service = Get-Service -Name $ServiceName -ErrorAction Stop
            $service.WaitForStatus(
                [System.ServiceProcess.ServiceControllerStatus]::Running,
                [TimeSpan]::FromSeconds($ServiceStartTimeoutSeconds)
            )
            $service.Refresh()
        }
        catch {
            $currentService = Get-Service -Name $ServiceName -ErrorAction SilentlyContinue
            $currentStatus = if ($null -ne $currentService) {
                [string]$currentService.Status
            }
            else {
                'NotFound'
            }

            Exit-OpsRampScript -ExitCode 32 -Message (
                'Service {0} did not reach Running status within {1} seconds. ' +
                'Current status: {2}. Error: {3}' -f
                $ServiceName,
                $ServiceStartTimeoutSeconds,
                $currentStatus,
                $_.Exception.Message
            )
        }
    }

    $service = Get-Service -Name $ServiceName -ErrorAction Stop
    $service.Refresh()

    Write-InstallLog -Message ('SERVICE_FINAL_STATUS={0}' -f $service.Status)

    if ($service.Status -ne 'Running') {
        Exit-OpsRampScript -ExitCode 32 -Message (
            'Service {0} exists but is not Running. Current status: {1}' -f
            $ServiceName,
            $service.Status
        )
    }

    Write-InstallLog -Message 'OPSRAMP_INSTALL_SUCCESS'
    Write-InstallLog -Message ('MSI_EXIT_CODE={0}' -f $msiExitCode)
    Write-InstallLog -Message ('SERVICE_NAME={0}' -f $service.Name)
    Write-InstallLog -Message ('SERVICE_STATUS={0}' -f $service.Status)
    Write-InstallLog -Message 'SCRIPT_EXIT_CODE=1'

    exit 1
}
catch {
    Write-InstallLog -Level 'ERROR' -Message (
        'UNEXPECTED_ERROR={0}' -f $_.Exception.Message
    )

    Write-InstallLog -Level 'ERROR' -Message (
        'EXCEPTION_TYPE={0}' -f $_.Exception.GetType().FullName
    )

    Write-InstallLog -Level 'ERROR' -Message (
        'ERROR_DETAILS={0}' -f ($_ | Out-String).Trim()
    )

    if (-not [string]::IsNullOrWhiteSpace($_.ScriptStackTrace)) {
        Write-InstallLog -Level 'ERROR' -Message (
            'SCRIPT_STACK_TRACE={0}' -f $_.ScriptStackTrace
        )
    }

    if ($null -ne $_.InvocationInfo) {
        if (-not [string]::IsNullOrWhiteSpace($_.InvocationInfo.Line)) {
            Write-InstallLog -Level 'ERROR' -Message (
                'FAILED_COMMAND={0}' -f $_.InvocationInfo.Line.Trim()
            )
        }

        if (-not [string]::IsNullOrWhiteSpace($_.InvocationInfo.PositionMessage)) {
            Write-InstallLog -Level 'ERROR' -Message (
                'ERROR_POSITION={0}' -f $_.InvocationInfo.PositionMessage.Trim()
            )
        }
    }

    Write-InstallLog -Level 'ERROR' -Message 'SCRIPT_EXIT_CODE=99'
    exit 99
}