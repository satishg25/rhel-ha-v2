# Microsoft Windows Server HA Vanilla

This playbook provisions two Windows VMs sequentially using the shared roles.
Provide shared request inputs once (such as `requestedfor`, `deploymenttype`,
`additionaldrives`, and `cloudstudio_onboarding`). Provide each server's
server-specific inputs and workflow state with a numeric suffix:

- Server 1: `servername1`, `ip1`, `dcname1`, and the corresponding other inputs/statuses.
- Server 2: `servername2`, `ip2`, `dcname2`, and the corresponding other inputs/statuses.

The shared roles still receive their original variable names; the playbook maps
each server's suffixed variables before running that server's workflow and saves
the role outputs back to the matching suffixed variables.

Datacenter policy for downstream roles:

- Roles 05, 08-17, 19-25, and 27 use `dc1-chz1` for both servers.
- Roles 06, 07, 18, and 26 use `dc1-chz1` for server 1 and `dc2-chz2` for server 2.
