# Improvements
## Correct template name for rhel-8

# Inputs
## Sample 1
servername: "tsvl-appd501"
ip: "10.160.52.19"
subnetmask: "255.255.255.0"
gateway: "10.160.52.1"
dns1: "10.160.48.10"
dns2: "10.24.5.10"
requestedfor: "bogdan.hristov@baloise.com"
deploymenttype: "standalone"
servertype: "bus"
sbu: "bits"
ostype: "linux"
environmenttype: "dev"
requestor: "hardik.jain@baloise.com"
metalcategory: "silver"
servicename: "MyCloud nonprod - MCD - SA"
addontype: "vanilla"
osversion: "rhel 8"
serversize: "medium2"
adgroupstobeadded: "F-AAD-WIPRO-CloudStudio-Admins"
additionaldrives:
  - additionaldrive: "/dev/sdc"
    group: "F-AAD-WIPRO-CloudStudio-Admins"
    mountpoint: "/data"
    size: 20
    user: "C051867@baloise.com"
    volumegroupname: "app_vg1"
is_vm_created: true
disk_configuration_completed: true
dcname: "dc2-chz2"

# Credentials to be attached with site.yml
## Name: email_request_received
### Credential Type: requestor_email
#### Input configuration: 
fields:
  - id: email_subject
    type: string
    label: Email Subject
    secret: false
  - id: email_body
    type: string
    label: Email Body
    secret: false
    multiline: true
required:
  - email_subject
  - email_body
#### Injector configuration:
env:
  EMAIL_BODY: '{{ email_body }}'
  EMAIL_SUBJECT: '{{ email_subject }}'
## Name: SMTP
### Credential Type: SMTP_Relay_Config
#### Input configuration: 
fields:
  - id: smtp_relay
    type: string
    label: SMTP relay
  - id: smtp_port
    type: string
    label: SMTP port
    default: '25'
  - id: smtp_from
    type: string
    label: SMTP from email
  - id: smtp_user
    type: string
    label: SMTP user
  - id: smtp_password
    type: string
    label: SMTP password
    secret: true
required:
  - smtp_relay
  - smtp_port
  - smtp_from
#### Injector configuration:
env:
  SMTP_FROM: '{{ smtp_from }}'
  SMTP_PORT: '{{ smtp_port }}'
  SMTP_USER: '{{ smtp_user }}'
  SMTP_RELAY: '{{ smtp_relay }}'
  SMTP_PASSWORD: '{{ smtp_password }}'
## Name: vc_res_selection
### Credential Type: vc_resource_selection
#### Input configuration:
fields:
  - id: vc_table_json
    type: string
    label: vCenter Mapping Table JSON
    secret: false
required:
  - vc_table_json
#### Injector configuration:
extra_vars:
  vc_table_json: '{{ vc_table_json }}'
## Name: VMware_vCenter_DC1
### Credential Type: VMware_vCenter_DC1
#### Input configuration:
fields:
  - id: vc_host_1
    type: string
    label: vCenter Host 1
  - id: vc_user_1
    type: string
    label: vCenter Username 1
  - id: vc_password_1
    type: string
    label: vCenter Password 1
    secret: true
  - id: vc_dc_1
    type: string
    label: Datacenter 1
  - id: vc_validate_certs_1
    type: boolean
    label: Validate Certificates 1
    default: false
required:
  - vc_host_1
  - vc_user_1
  - vc_password_1
  - vc_dc_1
#### Injector configuration:
env:
  VMWARE_DC1: '{{ vc_dc_1 }}'
  VMWARE_HOST_1: '{{ vc_host_1 }}'
  VMWARE_USER_1: '{{ vc_user_1 }}'
  VMWARE_PASSWORD_1: '{{ vc_password_1 }}'
  VMWARE_VALIDATE_CERTS_1: '{{ vc_validate_certs_1 }}'
## Name: VMware_vCenter_DC2
### Credential Type: VMware_vCenter_DC2
#### Input configuration:
fields:
  - id: vc_host_2
    type: string
    label: vCenter Host 2
  - id: vc_user_2
    type: string
    label: vCenter Username 2
  - id: vc_password_2
    type: string
    label: vCenter Password 2
    secret: true
  - id: vc_dc_2
    type: string
    label: Datacenter 2
  - id: vc_validate_certs_2
    type: boolean
    label: Validate Certificates 2
    default: false
required:
  - vc_host_2
  - vc_user_2
  - vc_password_2
  - vc_dc_2
#### Injector configuration:
env:
  VMWARE_DC2: '{{ vc_dc_2 }}'
  VMWARE_HOST_2: '{{ vc_host_2 }}'
  VMWARE_USER_2: '{{ vc_user_2 }}'
  VMWARE_PASSWORD_2: '{{ vc_password_2 }}'
  VMWARE_VALIDATE_CERTS_2: '{{ vc_validate_certs_2 }}'
## Name: vc_network_selection
### Credential Type: vc_network_selection
#### Input configuration:
fields:
  - id: network_table_json
    type: string
    label: Network Mapping Table JSON
    secret: false
required:
  - network_table_json
#### Injector configuration:
extra_vars:
  network_table_json: '{{ network_table_json }}'
## Name: tshirt_map
### Credential Type: tshirt_map
#### Input configuration:
fields:
  - id: tshirt_table_json
    type: string
    label: tshirt size to cpu and memory Mapping Table
    secret: false
required:
  - tshirt_table_json
#### Injector configuration:
extra_vars:
  tshirt_table_json: '{{ tshirt_table_json }}'
## Name: template_map
### Credential Type: template_map
#### Input configuration:
fields:
  - id: template_table_json
    type: string
    label: template Mapping Table
    secret: false
required:
  - template_table_json
#### Injector configuration:
extra_vars:
  template_table_json: '{{ template_table_json }}'
## Name: vCenter_VM_Parent_Folder
### Credential Type: vCenter_VM_Parent_Folder
#### Input configuration:
fields:
  - id: vm_parent_folder
    type: string
    label: VM Parent Folder Path
    secret: false
required:
  - vm_parent_folder
#### Injector configuration:
env:
  VM_PARENT_FOLDER: '{{ vm_parent_folder }}'
## Name: windows-local-admin
### Credential Type: Windows_Local_Admin
#### Input configuration:
fields:
  - id: app_username
    type: string
    label: Application Username
  - id: app_password
    type: string
    label: Application Password
    secret: true
required:
  - app_username
  - app_password
#### Injector configuration:
env:
  APP_PASSWORD: '{{ app_password }}'
  APP_USERNAME: '{{ app_username }}'
## Name: ad_cred
### Credential Type: ad_cred
#### Input configuration:
fields:
  - id: ad_domain
    type: string
    label: Active Directory Domain
  - id: ad_user
    type: string
    label: Active Directory Username
  - id: ad_password
    type: string
    label: Active Directory Password
    secret: true
  - id: ad_upn
    type: string
    label: Active Directory User Principal Name
required:
  - ad_domain
  - ad_user
  - ad_password
  - ad_upn
#### Injector configuration:
env:
  AD_UPN: '{{ ad_upn }}'
  AD_USER: '{{ ad_user }}'
  AD_DOMAIN: '{{ ad_domain }}'
  AD_PASSWORD: '{{ ad_password }}'
## Name: comp_ou
### Credential Type: ou
#### Input configuration:
fields:
  - id: ou_path
    type: string
    label: Target OU Path
    secret: false
required:
  - ou_path
#### Injector configuration:
env:
  OU_PATH: '{{ ou_path }}'
## Name: valuemation-test
### Credential Type: Valuemation_Credential
#### Input configuration:
fields:
  - id: valm_uri
    type: string
    label: Valuemation URI
  - id: valm_username
    type: string
    label: Valuemation Username
  - id: valm_password
    type: string
    label: Valuemation Password
    secret: true
required:
  - valm_uri
  - valm_username
  - valm_password
#### Injector configuration:
env:
  VALM_URI: '{{ valm_uri }}'
  VALM_PASSWORD: '{{ valm_password }}'
  VALM_USERNAME: '{{ valm_username }}'


# Credentials currently associated with each template
## 98_email_req_received
### Execution Environment: awx-vmware-ee:1.5
### Credentials
#### Name: email_request_received
##### Credential Type: requestor_email
###### Input configuration: 
fields:
  - id: email_subject
    type: string
    label: Email Subject
    secret: false
  - id: email_body
    type: string
    label: Email Body
    secret: false
    multiline: true
required:
  - email_subject
  - email_body
###### Injector configuration:
env:
  EMAIL_BODY: '{{ email_body }}'
  EMAIL_SUBJECT: '{{ email_subject }}'
#### Name: SMTP
##### Credential Type: SMTP_Relay_Config
###### Input configuration: 
fields:
  - id: smtp_relay
    type: string
    label: SMTP relay
  - id: smtp_port
    type: string
    label: SMTP port
    default: '25'
  - id: smtp_from
    type: string
    label: SMTP from email
  - id: smtp_user
    type: string
    label: SMTP user
  - id: smtp_password
    type: string
    label: SMTP password
    secret: true
required:
  - smtp_relay
  - smtp_port
  - smtp_from
###### Injector configuration:
env:
  SMTP_FROM: '{{ smtp_from }}'
  SMTP_PORT: '{{ smtp_port }}'
  SMTP_USER: '{{ smtp_user }}'
  SMTP_RELAY: '{{ smtp_relay }}'
  SMTP_PASSWORD: '{{ smtp_password }}'
## 2_cluster_dc_ar_storage_selection
### Execution Environment: AWX EE (latest)
### Credentials
#### Name: vc_res_selection
##### Credential Type: vc_resource_selection
###### Input configuration:
fields:
  - id: vc_table_json
    type: string
    label: vCenter Mapping Table JSON
    secret: false
required:
  - vc_table_json
###### Injector configuration:
extra_vars:
  vc_table_json: '{{ vc_table_json }}'
## 3_server_name_selection
### Execution Environment: AWX EE (latest)
### Credentials
#### Name: VMware_vCenter_DC1
##### Credential Type: VMware_vCenter_DC1
###### Input configuration:
fields:
  - id: vc_host_1
    type: string
    label: vCenter Host 1
  - id: vc_user_1
    type: string
    label: vCenter Username 1
  - id: vc_password_1
    type: string
    label: vCenter Password 1
    secret: true
  - id: vc_dc_1
    type: string
    label: Datacenter 1
  - id: vc_validate_certs_1
    type: boolean
    label: Validate Certificates 1
    default: false
required:
  - vc_host_1
  - vc_user_1
  - vc_password_1
  - vc_dc_1
###### Injector configuration:
env:
  VMWARE_DC1: '{{ vc_dc_1 }}'
  VMWARE_HOST_1: '{{ vc_host_1 }}'
  VMWARE_USER_1: '{{ vc_user_1 }}'
  VMWARE_PASSWORD_1: '{{ vc_password_1 }}'
  VMWARE_VALIDATE_CERTS_1: '{{ vc_validate_certs_1 }}'
#### Name: VMware_vCenter_DC2
##### Credential Type: VMware_vCenter_DC2
###### Input configuration:
fields:
  - id: vc_host_2
    type: string
    label: vCenter Host 2
  - id: vc_user_2
    type: string
    label: vCenter Username 2
  - id: vc_password_2
    type: string
    label: vCenter Password 2
    secret: true
  - id: vc_dc_2
    type: string
    label: Datacenter 2
  - id: vc_validate_certs_2
    type: boolean
    label: Validate Certificates 2
    default: false
required:
  - vc_host_2
  - vc_user_2
  - vc_password_2
  - vc_dc_2
###### Injector configuration:
env:
  VMWARE_DC2: '{{ vc_dc_2 }}'
  VMWARE_HOST_2: '{{ vc_host_2 }}'
  VMWARE_USER_2: '{{ vc_user_2 }}'
  VMWARE_PASSWORD_2: '{{ vc_password_2 }}'
  VMWARE_VALIDATE_CERTS_2: '{{ vc_validate_certs_2 }}'
## 4_network_selection:
### Execution Environment: AWX EE (latest)
### Credentials
#### Name: vc_network_selection
##### Credential Type: vc_network_selection
###### Input configuration:
fields:
  - id: network_table_json
    type: string
    label: Network Mapping Table JSON
    secret: false
required:
  - network_table_json
###### Injector configuration:
extra_vars:
  network_table_json: '{{ network_table_json }}'
#### Name: VMware_vCenter_DC1
##### Credential Type: VMware_vCenter_DC1
###### Input configuration:
fields:
  - id: vc_host_1
    type: string
    label: vCenter Host 1
  - id: vc_user_1
    type: string
    label: vCenter Username 1
  - id: vc_password_1
    type: string
    label: vCenter Password 1
    secret: true
  - id: vc_dc_1
    type: string
    label: Datacenter 1
  - id: vc_validate_certs_1
    type: boolean
    label: Validate Certificates 1
    default: false
required:
  - vc_host_1
  - vc_user_1
  - vc_password_1
  - vc_dc_1
###### Injector configuration:
env:
  VMWARE_DC1: '{{ vc_dc_1 }}'
  VMWARE_HOST_1: '{{ vc_host_1 }}'
  VMWARE_USER_1: '{{ vc_user_1 }}'
  VMWARE_PASSWORD_1: '{{ vc_password_1 }}'
  VMWARE_VALIDATE_CERTS_1: '{{ vc_validate_certs_1 }}'
#### Name: VMware_vCenter_DC2
##### Credential Type: VMware_vCenter_DC2
###### Input configuration:
fields:
  - id: vc_host_2
    type: string
    label: vCenter Host 2
  - id: vc_user_2
    type: string
    label: vCenter Username 2
  - id: vc_password_2
    type: string
    label: vCenter Password 2
    secret: true
  - id: vc_dc_2
    type: string
    label: Datacenter 2
  - id: vc_validate_certs_2
    type: boolean
    label: Validate Certificates 2
    default: false
required:
  - vc_host_2
  - vc_user_2
  - vc_password_2
  - vc_dc_2
###### Injector configuration:
env:
  VMWARE_DC2: '{{ vc_dc_2 }}'
  VMWARE_HOST_2: '{{ vc_host_2 }}'
  VMWARE_USER_2: '{{ vc_user_2 }}'
  VMWARE_PASSWORD_2: '{{ vc_password_2 }}'
  VMWARE_VALIDATE_CERTS_2: '{{ vc_validate_certs_2 }}'
## 5_host_datastore_selection:
### Execution Environment: AWX EE (latest)
### Credentials
#### Name: tshirt_map
##### Credential Type: tshirt_map
###### Input configuration:
fields:
  - id: tshirt_table_json
    type: string
    label: tshirt size to cpu and memory Mapping Table
    secret: false
required:
  - tshirt_table_json
###### Injector configuration:
extra_vars:
  tshirt_table_json: '{{ tshirt_table_json }}'
#### Name: VMware_vCenter_DC1
##### Credential Type: VMware_vCenter_DC1
###### Input configuration:
fields:
  - id: vc_host_1
    type: string
    label: vCenter Host 1
  - id: vc_user_1
    type: string
    label: vCenter Username 1
  - id: vc_password_1
    type: string
    label: vCenter Password 1
    secret: true
  - id: vc_dc_1
    type: string
    label: Datacenter 1
  - id: vc_validate_certs_1
    type: boolean
    label: Validate Certificates 1
    default: false
required:
  - vc_host_1
  - vc_user_1
  - vc_password_1
  - vc_dc_1
###### Injector configuration:
env:
  VMWARE_DC1: '{{ vc_dc_1 }}'
  VMWARE_HOST_1: '{{ vc_host_1 }}'
  VMWARE_USER_1: '{{ vc_user_1 }}'
  VMWARE_PASSWORD_1: '{{ vc_password_1 }}'
  VMWARE_VALIDATE_CERTS_1: '{{ vc_validate_certs_1 }}'
#### Name: VMware_vCenter_DC2
##### Credential Type: VMware_vCenter_DC2
###### Input configuration:
fields:
  - id: vc_host_2
    type: string
    label: vCenter Host 2
  - id: vc_user_2
    type: string
    label: vCenter Username 2
  - id: vc_password_2
    type: string
    label: vCenter Password 2
    secret: true
  - id: vc_dc_2
    type: string
    label: Datacenter 2
  - id: vc_validate_certs_2
    type: boolean
    label: Validate Certificates 2
    default: false
required:
  - vc_host_2
  - vc_user_2
  - vc_password_2
  - vc_dc_2
###### Injector configuration:
env:
  VMWARE_DC2: '{{ vc_dc_2 }}'
  VMWARE_HOST_2: '{{ vc_host_2 }}'
  VMWARE_USER_2: '{{ vc_user_2 }}'
  VMWARE_PASSWORD_2: '{{ vc_password_2 }}'
  VMWARE_VALIDATE_CERTS_2: '{{ vc_validate_certs_2 }}'
## 6_fetch_ip
### Execution Environment: AWX EE (latest)
## 7_select_template
### Execution Environment: AWX EE (latest)
### Credentials
#### Name: template_map
##### Credential Type: template_map
###### Input configuration:
fields:
  - id: template_table_json
    type: string
    label: template Mapping Table
    secret: false
required:
  - template_table_json
###### Injector configuration:
extra_vars:
  template_table_json: '{{ template_table_json }}'
#### Name: VMware_vCenter_DC1
##### Credential Type: VMware_vCenter_DC1
###### Input configuration:
fields:
  - id: vc_host_1
    type: string
    label: vCenter Host 1
  - id: vc_user_1
    type: string
    label: vCenter Username 1
  - id: vc_password_1
    type: string
    label: vCenter Password 1
    secret: true
  - id: vc_dc_1
    type: string
    label: Datacenter 1
  - id: vc_validate_certs_1
    type: boolean
    label: Validate Certificates 1
    default: false
required:
  - vc_host_1
  - vc_user_1
  - vc_password_1
  - vc_dc_1
###### Injector configuration:
env:
  VMWARE_DC1: '{{ vc_dc_1 }}'
  VMWARE_HOST_1: '{{ vc_host_1 }}'
  VMWARE_USER_1: '{{ vc_user_1 }}'
  VMWARE_PASSWORD_1: '{{ vc_password_1 }}'
  VMWARE_VALIDATE_CERTS_1: '{{ vc_validate_certs_1 }}'
#### Name: VMware_vCenter_DC2
##### Credential Type: VMware_vCenter_DC2
###### Input configuration:
fields:
  - id: vc_host_2
    type: string
    label: vCenter Host 2
  - id: vc_user_2
    type: string
    label: vCenter Username 2
  - id: vc_password_2
    type: string
    label: vCenter Password 2
    secret: true
  - id: vc_dc_2
    type: string
    label: Datacenter 2
  - id: vc_validate_certs_2
    type: boolean
    label: Validate Certificates 2
    default: false
required:
  - vc_host_2
  - vc_user_2
  - vc_password_2
  - vc_dc_2
###### Injector configuration:
env:
  VMWARE_DC2: '{{ vc_dc_2 }}'
  VMWARE_HOST_2: '{{ vc_host_2 }}'
  VMWARE_USER_2: '{{ vc_user_2 }}'
  VMWARE_PASSWORD_2: '{{ vc_password_2 }}'
  VMWARE_VALIDATE_CERTS_2: '{{ vc_validate_certs_2 }}'
## 8_vmware_create_vm_folder
### Execution Environment: AWX EE (latest)
### Credentials
#### Name: vCenter_VM_Parent_Folder
##### Credential Type: vCenter_VM_Parent_Folder
###### Input configuration:
fields:
  - id: vm_parent_folder
    type: string
    label: VM Parent Folder Path
    secret: false
required:
  - vm_parent_folder
###### Injector configuration:
env:
  VM_PARENT_FOLDER: '{{ vm_parent_folder }}'
#### Name: VMware_vCenter_DC1
##### Credential Type: VMware_vCenter_DC1
###### Input configuration:
fields:
  - id: vc_host_1
    type: string
    label: vCenter Host 1
  - id: vc_user_1
    type: string
    label: vCenter Username 1
  - id: vc_password_1
    type: string
    label: vCenter Password 1
    secret: true
  - id: vc_dc_1
    type: string
    label: Datacenter 1
  - id: vc_validate_certs_1
    type: boolean
    label: Validate Certificates 1
    default: false
required:
  - vc_host_1
  - vc_user_1
  - vc_password_1
  - vc_dc_1
###### Injector configuration:
env:
  VMWARE_DC1: '{{ vc_dc_1 }}'
  VMWARE_HOST_1: '{{ vc_host_1 }}'
  VMWARE_USER_1: '{{ vc_user_1 }}'
  VMWARE_PASSWORD_1: '{{ vc_password_1 }}'
  VMWARE_VALIDATE_CERTS_1: '{{ vc_validate_certs_1 }}'
#### Name: VMware_vCenter_DC2
##### Credential Type: VMware_vCenter_DC2
###### Input configuration:
fields:
  - id: vc_host_2
    type: string
    label: vCenter Host 2
  - id: vc_user_2
    type: string
    label: vCenter Username 2
  - id: vc_password_2
    type: string
    label: vCenter Password 2
    secret: true
  - id: vc_dc_2
    type: string
    label: Datacenter 2
  - id: vc_validate_certs_2
    type: boolean
    label: Validate Certificates 2
    default: false
required:
  - vc_host_2
  - vc_user_2
  - vc_password_2
  - vc_dc_2
###### Injector configuration:
env:
  VMWARE_DC2: '{{ vc_dc_2 }}'
  VMWARE_HOST_2: '{{ vc_host_2 }}'
  VMWARE_USER_2: '{{ vc_user_2 }}'
  VMWARE_PASSWORD_2: '{{ vc_password_2 }}'
  VMWARE_VALIDATE_CERTS_2: '{{ vc_validate_certs_2 }}'
## 9_vm_creation
### Execution Environment: AWX EE (latest)
### Credentials
#### Name: tshirt_map
##### Credential Type: tshirt_map
###### Input configuration:
fields:
  - id: tshirt_table_json
    type: string
    label: tshirt size to cpu and memory Mapping Table
    secret: false
required:
  - tshirt_table_json
###### Injector configuration:
extra_vars:
  tshirt_table_json: '{{ tshirt_table_json }}'
#### Name: VMware_vCenter_DC1
##### Credential Type: VMware_vCenter_DC1
###### Input configuration:
fields:
  - id: vc_host_1
    type: string
    label: vCenter Host 1
  - id: vc_user_1
    type: string
    label: vCenter Username 1
  - id: vc_password_1
    type: string
    label: vCenter Password 1
    secret: true
  - id: vc_dc_1
    type: string
    label: Datacenter 1
  - id: vc_validate_certs_1
    type: boolean
    label: Validate Certificates 1
    default: false
required:
  - vc_host_1
  - vc_user_1
  - vc_password_1
  - vc_dc_1
###### Injector configuration:
env:
  VMWARE_DC1: '{{ vc_dc_1 }}'
  VMWARE_HOST_1: '{{ vc_host_1 }}'
  VMWARE_USER_1: '{{ vc_user_1 }}'
  VMWARE_PASSWORD_1: '{{ vc_password_1 }}'
  VMWARE_VALIDATE_CERTS_1: '{{ vc_validate_certs_1 }}'
#### Name: VMware_vCenter_DC2
##### Credential Type: VMware_vCenter_DC2
###### Input configuration:
fields:
  - id: vc_host_2
    type: string
    label: vCenter Host 2
  - id: vc_user_2
    type: string
    label: vCenter Username 2
  - id: vc_password_2
    type: string
    label: vCenter Password 2
    secret: true
  - id: vc_dc_2
    type: string
    label: Datacenter 2
  - id: vc_validate_certs_2
    type: boolean
    label: Validate Certificates 2
    default: false
required:
  - vc_host_2
  - vc_user_2
  - vc_password_2
  - vc_dc_2
###### Injector configuration:
env:
  VMWARE_DC2: '{{ vc_dc_2 }}'
  VMWARE_HOST_2: '{{ vc_host_2 }}'
  VMWARE_USER_2: '{{ vc_user_2 }}'
  VMWARE_PASSWORD_2: '{{ vc_password_2 }}'
  VMWARE_VALIDATE_CERTS_2: '{{ vc_validate_certs_2 }}'
## 10_network_adapter_config
### Execution Environment: AWX EE (latest)
### Credentials
#### Name: VMware_vCenter_DC1
##### Credential Type: VMware_vCenter_DC1
###### Input configuration:
fields:
  - id: vc_host_1
    type: string
    label: vCenter Host 1
  - id: vc_user_1
    type: string
    label: vCenter Username 1
  - id: vc_password_1
    type: string
    label: vCenter Password 1
    secret: true
  - id: vc_dc_1
    type: string
    label: Datacenter 1
  - id: vc_validate_certs_1
    type: boolean
    label: Validate Certificates 1
    default: false
required:
  - vc_host_1
  - vc_user_1
  - vc_password_1
  - vc_dc_1
###### Injector configuration:
env:
  VMWARE_DC1: '{{ vc_dc_1 }}'
  VMWARE_HOST_1: '{{ vc_host_1 }}'
  VMWARE_USER_1: '{{ vc_user_1 }}'
  VMWARE_PASSWORD_1: '{{ vc_password_1 }}'
  VMWARE_VALIDATE_CERTS_1: '{{ vc_validate_certs_1 }}'
#### Name: VMware_vCenter_DC2
##### Credential Type: VMware_vCenter_DC2
###### Input configuration:
fields:
  - id: vc_host_2
    type: string
    label: vCenter Host 2
  - id: vc_user_2
    type: string
    label: vCenter Username 2
  - id: vc_password_2
    type: string
    label: vCenter Password 2
    secret: true
  - id: vc_dc_2
    type: string
    label: Datacenter 2
  - id: vc_validate_certs_2
    type: boolean
    label: Validate Certificates 2
    default: false
required:
  - vc_host_2
  - vc_user_2
  - vc_password_2
  - vc_dc_2
###### Injector configuration:
env:
  VMWARE_DC2: '{{ vc_dc_2 }}'
  VMWARE_HOST_2: '{{ vc_host_2 }}'
  VMWARE_USER_2: '{{ vc_user_2 }}'
  VMWARE_PASSWORD_2: '{{ vc_password_2 }}'
  VMWARE_VALIDATE_CERTS_2: '{{ vc_validate_certs_2 }}'
## 11_disk_configuration
### Execution Environment: AWX EE (latest)
### Credentials
#### Name: VMware_vCenter_DC1
##### Credential Type: VMware_vCenter_DC1
###### Input configuration:
fields:
  - id: vc_host_1
    type: string
    label: vCenter Host 1
  - id: vc_user_1
    type: string
    label: vCenter Username 1
  - id: vc_password_1
    type: string
    label: vCenter Password 1
    secret: true
  - id: vc_dc_1
    type: string
    label: Datacenter 1
  - id: vc_validate_certs_1
    type: boolean
    label: Validate Certificates 1
    default: false
required:
  - vc_host_1
  - vc_user_1
  - vc_password_1
  - vc_dc_1
###### Injector configuration:
env:
  VMWARE_DC1: '{{ vc_dc_1 }}'
  VMWARE_HOST_1: '{{ vc_host_1 }}'
  VMWARE_USER_1: '{{ vc_user_1 }}'
  VMWARE_PASSWORD_1: '{{ vc_password_1 }}'
  VMWARE_VALIDATE_CERTS_1: '{{ vc_validate_certs_1 }}'
#### Name: VMware_vCenter_DC2
##### Credential Type: VMware_vCenter_DC2
###### Input configuration:
fields:
  - id: vc_host_2
    type: string
    label: vCenter Host 2
  - id: vc_user_2
    type: string
    label: vCenter Username 2
  - id: vc_password_2
    type: string
    label: vCenter Password 2
    secret: true
  - id: vc_dc_2
    type: string
    label: Datacenter 2
  - id: vc_validate_certs_2
    type: boolean
    label: Validate Certificates 2
    default: false
required:
  - vc_host_2
  - vc_user_2
  - vc_password_2
  - vc_dc_2
###### Injector configuration:
env:
  VMWARE_DC2: '{{ vc_dc_2 }}'
  VMWARE_HOST_2: '{{ vc_host_2 }}'
  VMWARE_USER_2: '{{ vc_user_2 }}'
  VMWARE_PASSWORD_2: '{{ vc_password_2 }}'
  VMWARE_VALIDATE_CERTS_2: '{{ vc_validate_certs_2 }}'
## 12_vmtool_update_poweredon
### Execution Environment: AWX EE (latest)
### Credentials
#### Name: VMware_vCenter_DC1
##### Credential Type: VMware_vCenter_DC1
###### Input configuration:
fields:
  - id: vc_host_1
    type: string
    label: vCenter Host 1
  - id: vc_user_1
    type: string
    label: vCenter Username 1
  - id: vc_password_1
    type: string
    label: vCenter Password 1
    secret: true
  - id: vc_dc_1
    type: string
    label: Datacenter 1
  - id: vc_validate_certs_1
    type: boolean
    label: Validate Certificates 1
    default: false
required:
  - vc_host_1
  - vc_user_1
  - vc_password_1
  - vc_dc_1
###### Injector configuration:
env:
  VMWARE_DC1: '{{ vc_dc_1 }}'
  VMWARE_HOST_1: '{{ vc_host_1 }}'
  VMWARE_USER_1: '{{ vc_user_1 }}'
  VMWARE_PASSWORD_1: '{{ vc_password_1 }}'
  VMWARE_VALIDATE_CERTS_1: '{{ vc_validate_certs_1 }}'
#### Name: VMware_vCenter_DC2
##### Credential Type: VMware_vCenter_DC2
###### Input configuration:
fields:
  - id: vc_host_2
    type: string
    label: vCenter Host 2
  - id: vc_user_2
    type: string
    label: vCenter Username 2
  - id: vc_password_2
    type: string
    label: vCenter Password 2
    secret: true
  - id: vc_dc_2
    type: string
    label: Datacenter 2
  - id: vc_validate_certs_2
    type: boolean
    label: Validate Certificates 2
    default: false
required:
  - vc_host_2
  - vc_user_2
  - vc_password_2
  - vc_dc_2
###### Injector configuration:
env:
  VMWARE_DC2: '{{ vc_dc_2 }}'
  VMWARE_HOST_2: '{{ vc_host_2 }}'
  VMWARE_USER_2: '{{ vc_user_2 }}'
  VMWARE_PASSWORD_2: '{{ vc_password_2 }}'
  VMWARE_VALIDATE_CERTS_2: '{{ vc_validate_certs_2 }}'
## 13_ip_configuration_win:
### Execution Environment: AWX VMware EE 1.6.1
### Credentials
#### Name: VMware_vCenter_DC1
##### Credential Type: VMware_vCenter_DC1
###### Input configuration:
fields:
  - id: vc_host_1
    type: string
    label: vCenter Host 1
  - id: vc_user_1
    type: string
    label: vCenter Username 1
  - id: vc_password_1
    type: string
    label: vCenter Password 1
    secret: true
  - id: vc_dc_1
    type: string
    label: Datacenter 1
  - id: vc_validate_certs_1
    type: boolean
    label: Validate Certificates 1
    default: false
required:
  - vc_host_1
  - vc_user_1
  - vc_password_1
  - vc_dc_1
###### Injector configuration:
env:
  VMWARE_DC1: '{{ vc_dc_1 }}'
  VMWARE_HOST_1: '{{ vc_host_1 }}'
  VMWARE_USER_1: '{{ vc_user_1 }}'
  VMWARE_PASSWORD_1: '{{ vc_password_1 }}'
  VMWARE_VALIDATE_CERTS_1: '{{ vc_validate_certs_1 }}'
#### Name: VMware_vCenter_DC2
##### Credential Type: VMware_vCenter_DC2
###### Input configuration:
fields:
  - id: vc_host_2
    type: string
    label: vCenter Host 2
  - id: vc_user_2
    type: string
    label: vCenter Username 2
  - id: vc_password_2
    type: string
    label: vCenter Password 2
    secret: true
  - id: vc_dc_2
    type: string
    label: Datacenter 2
  - id: vc_validate_certs_2
    type: boolean
    label: Validate Certificates 2
    default: false
required:
  - vc_host_2
  - vc_user_2
  - vc_password_2
  - vc_dc_2
###### Injector configuration:
env:
  VMWARE_DC2: '{{ vc_dc_2 }}'
  VMWARE_HOST_2: '{{ vc_host_2 }}'
  VMWARE_USER_2: '{{ vc_user_2 }}'
  VMWARE_PASSWORD_2: '{{ vc_password_2 }}'
  VMWARE_VALIDATE_CERTS_2: '{{ vc_validate_certs_2 }}'
#### Name: windows-local-admin
##### Credential Type: Windows_Local_Admin
###### Input configuration:
fields:
  - id: app_username
    type: string
    label: Application Username
  - id: app_password
    type: string
    label: Application Password
    secret: true
required:
  - app_username
  - app_password
###### Injector configuration:
env:
  APP_PASSWORD: '{{ app_password }}'
  APP_USERNAME: '{{ app_username }}'
## 14_drive_config
### Execution Environment: AWX EE (latest)
### Credentials
#### Name: VMware_vCenter_DC1
##### Credential Type: VMware_vCenter_DC1
###### Input configuration:
fields:
  - id: vc_host_1
    type: string
    label: vCenter Host 1
  - id: vc_user_1
    type: string
    label: vCenter Username 1
  - id: vc_password_1
    type: string
    label: vCenter Password 1
    secret: true
  - id: vc_dc_1
    type: string
    label: Datacenter 1
  - id: vc_validate_certs_1
    type: boolean
    label: Validate Certificates 1
    default: false
required:
  - vc_host_1
  - vc_user_1
  - vc_password_1
  - vc_dc_1
###### Injector configuration:
env:
  VMWARE_DC1: '{{ vc_dc_1 }}'
  VMWARE_HOST_1: '{{ vc_host_1 }}'
  VMWARE_USER_1: '{{ vc_user_1 }}'
  VMWARE_PASSWORD_1: '{{ vc_password_1 }}'
  VMWARE_VALIDATE_CERTS_1: '{{ vc_validate_certs_1 }}'
#### Name: VMware_vCenter_DC2
##### Credential Type: VMware_vCenter_DC2
###### Input configuration:
fields:
  - id: vc_host_2
    type: string
    label: vCenter Host 2
  - id: vc_user_2
    type: string
    label: vCenter Username 2
  - id: vc_password_2
    type: string
    label: vCenter Password 2
    secret: true
  - id: vc_dc_2
    type: string
    label: Datacenter 2
  - id: vc_validate_certs_2
    type: boolean
    label: Validate Certificates 2
    default: false
required:
  - vc_host_2
  - vc_user_2
  - vc_password_2
  - vc_dc_2
###### Injector configuration:
env:
  VMWARE_DC2: '{{ vc_dc_2 }}'
  VMWARE_HOST_2: '{{ vc_host_2 }}'
  VMWARE_USER_2: '{{ vc_user_2 }}'
  VMWARE_PASSWORD_2: '{{ vc_password_2 }}'
  VMWARE_VALIDATE_CERTS_2: '{{ vc_validate_certs_2 }}'
#### Name: windows-local-admin
##### Credential Type: Windows_Local_Admin
###### Input configuration:
fields:
  - id: app_username
    type: string
    label: Application Username
  - id: app_password
    type: string
    label: Application Password
    secret: true
required:
  - app_username
  - app_password
###### Injector configuration:
env:
  APP_PASSWORD: '{{ app_password }}'
  APP_USERNAME: '{{ app_username }}'
## 15_domain_join_win
### Execution Environment: awx-vmware-ee:1.7.2
### Credentials
#### Name: VMware_vCenter_DC1
##### Credential Type: VMware_vCenter_DC1
###### Input configuration:
fields:
  - id: vc_host_1
    type: string
    label: vCenter Host 1
  - id: vc_user_1
    type: string
    label: vCenter Username 1
  - id: vc_password_1
    type: string
    label: vCenter Password 1
    secret: true
  - id: vc_dc_1
    type: string
    label: Datacenter 1
  - id: vc_validate_certs_1
    type: boolean
    label: Validate Certificates 1
    default: false
required:
  - vc_host_1
  - vc_user_1
  - vc_password_1
  - vc_dc_1
###### Injector configuration:
env:
  VMWARE_DC1: '{{ vc_dc_1 }}'
  VMWARE_HOST_1: '{{ vc_host_1 }}'
  VMWARE_USER_1: '{{ vc_user_1 }}'
  VMWARE_PASSWORD_1: '{{ vc_password_1 }}'
  VMWARE_VALIDATE_CERTS_1: '{{ vc_validate_certs_1 }}'
#### Name: VMware_vCenter_DC2
##### Credential Type: VMware_vCenter_DC2
###### Input configuration:
fields:
  - id: vc_host_2
    type: string
    label: vCenter Host 2
  - id: vc_user_2
    type: string
    label: vCenter Username 2
  - id: vc_password_2
    type: string
    label: vCenter Password 2
    secret: true
  - id: vc_dc_2
    type: string
    label: Datacenter 2
  - id: vc_validate_certs_2
    type: boolean
    label: Validate Certificates 2
    default: false
required:
  - vc_host_2
  - vc_user_2
  - vc_password_2
  - vc_dc_2
###### Injector configuration:
env:
  VMWARE_DC2: '{{ vc_dc_2 }}'
  VMWARE_HOST_2: '{{ vc_host_2 }}'
  VMWARE_USER_2: '{{ vc_user_2 }}'
  VMWARE_PASSWORD_2: '{{ vc_password_2 }}'
  VMWARE_VALIDATE_CERTS_2: '{{ vc_validate_certs_2 }}'
#### Name: windows-local-admin
##### Credential Type: Windows_Local_Admin
###### Input configuration:
fields:
  - id: app_username
    type: string
    label: Application Username
  - id: app_password
    type: string
    label: Application Password
    secret: true
required:
  - app_username
  - app_password
###### Injector configuration:
env:
  APP_PASSWORD: '{{ app_password }}'
  APP_USERNAME: '{{ app_username }}'
#### Name: ad_cred
##### Credential Type: ad_cred
###### Input configuration:
fields:
  - id: ad_domain
    type: string
    label: Active Directory Domain
  - id: ad_user
    type: string
    label: Active Directory Username
  - id: ad_password
    type: string
    label: Active Directory Password
    secret: true
  - id: ad_upn
    type: string
    label: Active Directory User Principal Name
required:
  - ad_domain
  - ad_user
  - ad_password
  - ad_upn
###### Injector configuration:
env:
  AD_UPN: '{{ ad_upn }}'
  AD_USER: '{{ ad_user }}'
  AD_DOMAIN: '{{ ad_domain }}'
  AD_PASSWORD: '{{ ad_password }}'
#### Name: comp_ou
##### Credential Type: ou
###### Input configuration:
fields:
  - id: ou_path
    type: string
    label: Target OU Path
    secret: false
required:
  - ou_path
###### Injector configuration:
env:
  OU_PATH: '{{ ou_path }}'
## 16_valuemation
### Execution Environment: AWX EE (latest)
### Credentials
#### Name: valuemation-test
##### Credential Type: Valuemation_Credential
###### Input configuration:
fields:
  - id: valm_uri
    type: string
    label: Valuemation URI
  - id: valm_username
    type: string
    label: Valuemation Username
  - id: valm_password
    type: string
    label: Valuemation Password
    secret: true
required:
  - valm_uri
  - valm_username
  - valm_password
###### Injector configuration:
env:
  VALM_URI: '{{ valm_uri }}'
  VALM_PASSWORD: '{{ valm_password }}'
  VALM_USERNAME: '{{ valm_username }}'
## 100_Debug_params
### Execution Environment: AWX EE (latest)
## 97_email_success
### Execution Environment: awx-vmware-ee:1.5
### Credentials
### Name: SMTP
##### Credential Type: SMTP_Relay_Config
###### Input configuration: 
fields:
  - id: smtp_relay
    type: string
    label: SMTP relay
  - id: smtp_port
    type: string
    label: SMTP port
    default: '25'
  - id: smtp_from
    type: string
    label: SMTP from email
  - id: smtp_user
    type: string
    label: SMTP user
  - id: smtp_password
    type: string
    label: SMTP password
    secret: true
required:
  - smtp_relay
  - smtp_port
  - smtp_from
###### Injector configuration:
env:
  SMTP_FROM: '{{ smtp_from }}'
  SMTP_PORT: '{{ smtp_port }}'
  SMTP_USER: '{{ smtp_user }}'
  SMTP_RELAY: '{{ smtp_relay }}'
  SMTP_PASSWORD: '{{ smtp_password }}'
## 99_Send_Failure_Email
### Execution Environment: awx-vmware-ee:1.5
### Credentials
### Name: SMTP
##### Credential Type: SMTP_Relay_Config
###### Input configuration: 
fields:
  - id: smtp_relay
    type: string
    label: SMTP relay
  - id: smtp_port
    type: string
    label: SMTP port
    default: '25'
  - id: smtp_from
    type: string
    label: SMTP from email
  - id: smtp_user
    type: string
    label: SMTP user
  - id: smtp_password
    type: string
    label: SMTP password
    secret: true
required:
  - smtp_relay
  - smtp_port
  - smtp_from
###### Injector configuration:
env:
  SMTP_FROM: '{{ smtp_from }}'
  SMTP_PORT: '{{ smtp_port }}'
  SMTP_USER: '{{ smtp_user }}'
  SMTP_RELAY: '{{ smtp_relay }}'
  SMTP_PASSWORD: '{{ smtp_password }}'
## 96_bau_send_failure_email
### Execution Environment: awx-vmware-ee:1.5
### Credentials
### Name: SMTP
##### Credential Type: SMTP_Relay_Config
###### Input configuration: 
fields:
  - id: smtp_relay
    type: string
    label: SMTP relay
  - id: smtp_port
    type: string
    label: SMTP port
    default: '25'
  - id: smtp_from
    type: string
    label: SMTP from email
  - id: smtp_user
    type: string
    label: SMTP user
  - id: smtp_password
    type: string
    label: SMTP password
    secret: true
required:
  - smtp_relay
  - smtp_port
  - smtp_from
###### Injector configuration:
env:
  SMTP_FROM: '{{ smtp_from }}'
  SMTP_PORT: '{{ smtp_port }}'
  SMTP_USER: '{{ smtp_user }}'
  SMTP_RELAY: '{{ smtp_relay }}'
  SMTP_PASSWORD: '{{ smtp_password }}'



## Unique Injectors
EMAIL_BODY
EMAIL_SUBJECT
SMTP_FROM
SMTP_PORT
SMTP_USER
SMTP_RELAY
SMTP_PASSWORD
vc_table_json
VMWARE_DC1
VMWARE_HOST_1
VMWARE_USER_1
VMWARE_PASSWORD_1
VMWARE_VALIDATE_CERTS_1
VMWARE_DC2
VMWARE_HOST_2
VMWARE_USER_2
VMWARE_PASSWORD_2
VMWARE_VALIDATE_CERTS_2
network_table_json
tshirt_table_json
template_table_json
VM_PARENT_FOLDER
APP_PASSWORD
APP_USERNAME
VALM_URI
VALM_PASSWORD
VALM_USERNAME

